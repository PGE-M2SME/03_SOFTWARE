#include <gui/screenanalyseb_screen/ScreenanalysebView.hpp>

ScreenanalysebView::ScreenanalysebView()
{

}

void ScreenanalysebView::setupScreen()
{
    ScreenanalysebViewBase::setupScreen();
}

void ScreenanalysebView::tearDownScreen()
{
    ScreenanalysebViewBase::tearDownScreen();
}
