#include <gui/screenanalyseb_screen/ScreenanalysebView.hpp>
#include <gui/screenanalyseb_screen/ScreenanalysebPresenter.hpp>

ScreenanalysebPresenter::ScreenanalysebPresenter(ScreenanalysebView& v)
    : view(v)
{

}

void ScreenanalysebPresenter::activate()
{

}

void ScreenanalysebPresenter::deactivate()
{

}
