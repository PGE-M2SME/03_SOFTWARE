#include <gui/screenanalysef_screen/ScreenanalysefView.hpp>

ScreenanalysefView::ScreenanalysefView()
{

}

void ScreenanalysefView::setupScreen()
{
    ScreenanalysefViewBase::setupScreen();
}

void ScreenanalysefView::tearDownScreen()
{
    ScreenanalysefViewBase::tearDownScreen();
}
