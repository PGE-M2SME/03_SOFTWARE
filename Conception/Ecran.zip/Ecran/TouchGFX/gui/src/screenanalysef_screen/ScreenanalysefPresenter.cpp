#include <gui/screenanalysef_screen/ScreenanalysefView.hpp>
#include <gui/screenanalysef_screen/ScreenanalysefPresenter.hpp>

ScreenanalysefPresenter::ScreenanalysefPresenter(ScreenanalysefView& v)
    : view(v)
{

}

void ScreenanalysefPresenter::activate()
{

}

void ScreenanalysefPresenter::deactivate()
{

}
