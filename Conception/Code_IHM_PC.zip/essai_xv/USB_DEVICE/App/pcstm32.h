/*
 * pcstm32.h
 *
 *  Created on: 7 févr. 2021
 *      Author: Manoah
 */

#ifndef APP_PCSTM32_H_
#define APP_PCSTM32_H_

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "usb_device.h"
#include "usbd_cdc_if.h"
#include "string.h"

/* Struct --------------------------------------------------------------------*/
typedef struct {
    int width;
    int height;
    int mire;
    int standard;
} s_gen_flux;

typedef struct {
    int protocole;
    int freq;
    int octet;
    int motbinaire;
} s_gen_bus;

typedef struct {
    int freq;
    int octet;
    int motbinaire;
} s_rec_bus;

typedef struct {
    int width;
    int height;
    int blankingH;
    int blankingV;
    int framerate;
} s_rec_flux;

/* Prototypes ----------------------------------------------------------------*/
void confirmationCMD(uint8_t cmd, void* str);
void envoiePCSTM(uint8_t* Buf, uint16_t Len);
void s_gen_flux_config(s_gen_flux* gf);
void s_gen_bus_config(s_gen_bus* gb);
void s_rec_bus_config(s_rec_bus* rb);
void s_rec_flux_config(s_rec_flux* rf);
void help(void);
void clear_buffer(uint8_t * buffer_verif);

#endif /* APP_PCSTM32_H_ */
