/*
 * pcstm32.c
 *
 *  Created on: 7 févr. 2021
 *      Author: Manoah
 */
/* Includes ------------------------------------------------------------------*/
#include "pcstm32.h"

/* Defines -------------------------------------------------------------------*/
#define erreur() envoiePCSTM("\nErreur\n",  strlen("\nErreur\n")); return;
#define GENERATION_FLUX_CMD 1
#define GENERATION_BUS_CMD 2
#define	RECEPTION_BUS_CMD 3
#define RECEPTION_FLUX_CMD 4
#define N_MIRES 10
#define N_STANDARDS 2
#define	N_PROTOCOLE 3
/* Privates Variables --------------------------------------------------------*/
extern uint8_t buffer_verif[64];

/* Codes ---------------------------------------------------------------------*/
void s_gen_flux_config(s_gen_flux* gf)
{   help();
    uint8_t test[20], dummy[2];
    sscanf((char *) buffer_verif, "%s", (char *) test);

    if(memcmp(test, "genFlux", strlen("genFlux")) == 0)
    {
        char *p = strstr((char *) buffer_verif, "-r");
        if(p) {
            sscanf(p, "%s %d %s %d", dummy, &gf->width, dummy, &gf->height);
            if((gf->width==0) || (gf->height==0)) {
            	erreur();
            }
        }

        p = strstr((char *) buffer_verif, "-m");
        if(p) {
            sscanf(p, "%s %d", dummy, &(gf->mire));
            if((gf->mire == 0) || (gf->mire > N_MIRES)) {
            	erreur();
            }
        }

        p = strstr((char *) buffer_verif, "-s");
        if(p) {
            sscanf(p, "%s %d", dummy, &(gf->standard));
            if((gf->standard==0) || (gf->standard > N_STANDARDS)) {
            	erreur();
            }
        }

        confirmationCMD(GENERATION_FLUX_CMD, (void*) gf);
    }


}

void s_gen_bus_config(s_gen_bus* gb)
{
    uint8_t test[20], dummy[2];
    sscanf((char *) buffer_verif, "%s", (char *) test);

    if(memcmp(test, "genBus", strlen("genBus")) == 0)
    {
        char *p = strstr((char *) buffer_verif, "-p");
        if(p) {
            sscanf(p, "%s %d", dummy, &gb->protocole);
            if((gb->protocole==0)|| (gb->protocole > N_PROTOCOLE)) {
            	erreur();
            }
        }

        p = strstr((char *) buffer_verif, "-f");
        if(p) {
            sscanf(p, "%s %d", dummy, &(gb->freq));
            if(gb->freq == 0) {
            	erreur();
            }
        }

        p = strstr((char *) buffer_verif, "-o");
        if(p) {
            sscanf(p, "%s %d", dummy, &(gb->octet));
            if(gb->octet==0) {
            	erreur();
            }
        }

        p = strstr((char *) buffer_verif, "-m");
        if(p) {
            sscanf(p, "%s %d", dummy, &(gb->motbinaire));
            if(gb->motbinaire==0) {
            	erreur();
            }
        }

        confirmationCMD(GENERATION_BUS_CMD, (void*) gb);
    }


}

void s_rec_bus_config(s_rec_bus* rb)
{
		uint8_t dr[8];
		sscanf((char *) buffer_verif, "%s", (char *) dr);

		if(memcmp(dr, "recBus", strlen("recBus")) == 0)
		{
			confirmationCMD(RECEPTION_BUS_CMD, (void*) rb);
			//ajouter la variable vous indiquant de modifier les champs des structures attendues
		}
}

void s_rec_flux_config(s_rec_flux* rf)
{
		uint8_t dfl[8];
		sscanf((char *) buffer_verif, "%s", (char *) dfl);

		if(memcmp(dfl, "recFlux", strlen("recFlux")) == 0)
		{
			confirmationCMD(RECEPTION_FLUX_CMD, (void*) rf);
			//ajouter la variable vous indiquant de modifier les champs des structures attendues
		}
}

void help(void)
{
    uint8_t h[20];
    sscanf((char *) buffer_verif, "%s", (char *) h);

    if(memcmp(h, "help", strlen("help")) == 0)
    {
    	uint8_t *help = "\nHELP \n";
   		envoiePCSTM(help, strlen(help));
    	uint8_t *help1 = "genBus sert a definir les parametres";
   		envoiePCSTM(help1, strlen(help1));
    	uint8_t *help2 = " pour la communication via UART, I2C et SPI \n";
   		envoiePCSTM(help2, strlen(help2));
    	uint8_t *help3 = "Ces commandes sont :\n";
   		envoiePCSTM(help3, strlen(help3));
    	uint8_t *help4 = "-p doit etre suivi d'un entier tel que: \n";
   		envoiePCSTM(help4, strlen(help4));
    	uint8_t *help5 = " 1 pour I2C \n 2 pour UART \n 3 pour SPI\n";
   		envoiePCSTM(help5, strlen(help5));
    	uint8_t *help6 = "-f doit etre suivi d'un entier representatif de la frequence de la communication \n";
   		envoiePCSTM(help6, strlen(help6));
    	uint8_t *help7 = "-o doit etre suivi d'un entier representatif du nombre d'octet de la communication \n";
   		envoiePCSTM(help7, strlen(help7));
    	uint8_t *help8 = "-m doit etre suivi d'un entier representatif d'un mot binaire \n";
   		envoiePCSTM(help8, strlen(help8));
        uint8_t *help18 = "Exemple d'utilisation de genBus \n genBus -p 1 -f 9 -o 1 -m 11011011 \n";
       	envoiePCSTM(help18, strlen(help18));

    	uint8_t *help9 = "\ngenFlux sert a definir les parametres pour generer une mire \n";
   		envoiePCSTM(help9, strlen(help9));
    	uint8_t *help10 = "Ces commandes sont :  \n";
   		envoiePCSTM(help10, strlen(help10));
    	uint8_t *help11 = "-r doit etre suivi de deux entiers representatifs de la resolution tel que entier x entier \n";
   		envoiePCSTM(help11, strlen(help11));
    	uint8_t *help12 = "-m doit etre suivi d'un entier representatif du type de la mire \n";
   		envoiePCSTM(help12, strlen(help12));
    	uint8_t *help13 = " 1 pour Mire barre code \n 2 pour Mire contour blanc \n 3 pour Mire green/red\n 4 pour Mire horizontalBandMire\n 5 pour Mire horizontalShadeGray\n";
   		envoiePCSTM(help13, strlen(help13));
    	uint8_t *help14 = " 6 pour Mire PatchWork\n 7 pour Mire RectShadesGray\n 8 pour Mire SwitchBlackWhite\n 9 pour Mire VerticalBlandMire\n 10 pour Mire VerticalShadesGray\n";
   		envoiePCSTM(help14, strlen(help14));
    	uint8_t *help15 = "-s doit etre suivi d'un entier representatif du standard \n";
       	envoiePCSTM(help15, strlen(help15));
        uint8_t *help16 = " 1 pour SDI \n 2 pour HDMI \n";
       	envoiePCSTM(help16, strlen(help16));
        uint8_t *help17 = "Exemple d'utilisation de genFlux \n genFlux -r 1920 x 1080 -m 9 -s 1 \n";
       	envoiePCSTM(help17, strlen(help17));

    	uint8_t *help20 = "\nrecBus sert a afficher les informations d'un bus de communication tel que: la resolution, le blanking et le framerate \n";
   		envoiePCSTM(help20, strlen(help20));

    	uint8_t *help21 = "\nrecFlux sert a afficher les informations d'un flux video tel que: la frequence, l'octet et le mot binaire \n";
   		envoiePCSTM(help21, strlen(help21));
    }
    else
    {
    }

}

void confirmationCMD(uint8_t cmd, void* str)
{
    uint8_t temp[150] = {0};
    uint8_t var[150] = {0};
    uint8_t tab[150] = {0};
    uint8_t dat[150] = {0};
    sprintf((char *) temp, "\nGENERATION FLUX VIDEO \n"
    		"Standard :");
    if(cmd == GENERATION_FLUX_CMD) {
   		s_gen_flux* gf = (s_gen_flux*) str;

   		if(gf->standard == 1){
   			sprintf((char *) temp, "%s SDI\n", (char *) temp);
   		}
   		else if(gf->standard == 2){
   			sprintf((char *) temp, "%s HDMI\n", (char *) temp);
   		}

   		sprintf((char *) temp, "%sResolution : %dx%d \n", (char *) temp, gf->width, gf->height);

   		switch (gf->mire)
   		{
   		case 1:
   			sprintf((char *) temp, "%sMire :  barre code\n", (char *) temp);
   		  break;
   		case 2:
   			sprintf((char *) temp, "%sMire :  contour blanc\n", (char *) temp);
   		  break;
   		case 3:
   			sprintf((char *) temp, "%sMire :  green_red\n", (char *) temp);
   		  break;
   		case 4:
   			sprintf((char *) temp, "%sMire : horizontalBandMire\n", (char *) temp);
   		  break;
   		case 5:
   			sprintf((char *) temp, "%sMire :  horizontalShadeGray\n", (char *) temp);
   		  break;
   		case 6:
   			sprintf((char *) temp, "%sMire :  PatchWork\n", (char *) temp);
   		  break;
   		case 7:
   			sprintf((char *) temp, "%sMire :  RectShadesGray\n", (char *) temp);
   		  break;
   		case 8:
   			sprintf((char *) temp, "%sMire :  SwitchBlackWhite\n", (char *) temp);
   		  break;
   		case 9:
   			sprintf((char *) temp, "%sMire :  VerticalBlandMire\n", (char *) temp);
   		  break;
   		case 10:
   			sprintf((char *) temp, "%sMire :  VerticalShadesGray\n", (char *) temp);
   		  break;
   		}
    		envoiePCSTM(temp, strlen((char *) temp));
    }

    sprintf((char *) var, "\nGENERATION BUS COMMUNICATION \n"
    		"Protocole :");
    if(cmd == GENERATION_BUS_CMD) {
   		s_gen_bus* gb = (s_gen_bus*) str;

   		if(gb->protocole == 1){
   			sprintf((char *) var, "%s I2C\n", (char *) var);
   		}
   		else if(gb->protocole == 2){
   			sprintf((char *) var, "%s UART\n", (char *) var);
   		}
   		else if(gb->protocole == 3){
   			sprintf((char *) var, "%s SPI\n", (char *) var);
   		}

   		sprintf((char *) var, "%sFrequence : %d \n", (char *) var, gb->freq);
   		sprintf((char *) var, "%sOctet : %d \n", (char *) var, gb->octet);
   		sprintf((char *) var, "%sMot binaire : %d \n", (char *) var, gb->motbinaire);

   		envoiePCSTM(var, strlen((char *) var));
    }

    sprintf((char *) tab, "\nRECEPTION BUS COMMUNICATION \n");
    if(cmd == RECEPTION_BUS_CMD) {
    	s_rec_bus* rb = (s_rec_bus*) str;

   		sprintf((char *) tab, "%sFrequence : %d \n", (char *) tab, rb->freq);
   		sprintf((char *) tab, "%sOctet : %d \n", (char *) tab, rb->octet);
   		sprintf((char *) tab, "%sMot binaire : %d \n", (char *) tab, rb->motbinaire);

   		envoiePCSTM(tab, strlen((char *) tab));
    }

    sprintf((char *) dat, "\nRECEPTION FLUX VIDEO\n");
    if(cmd == RECEPTION_FLUX_CMD) {
    	s_rec_flux* rf = (s_rec_flux*) str;

   		sprintf((char *) dat, "%sResolution : %dx%d\n", (char *) dat, rf->width, rf->height);
   		sprintf((char *) dat, "%sBlanking : %dx%d \n", (char *) dat, rf->blankingH, rf->blankingV);
   		sprintf((char *) dat, "%sFramerate : %d \n", (char *) dat, rf->framerate);

   		envoiePCSTM(dat, strlen((char *) dat));
    }
}

void envoiePCSTM(uint8_t* Buf, uint16_t Len)
{
	 CDC_Transmit_FS(Buf, Len); //Si on veut envoyer via un autre dispositif on peut le faire
	 HAL_Delay(10);
}

void clear_buffer(uint8_t * buffer_verif)
{
    int i;
    for(i=0; i<64; i++)
    {
            	buffer_verif[i]='\0';
    }

}
